function goAppleDetail(loc) {
	location.href = "AppleDetailController?a_location=" + loc;
}

function deleteApple(loc) {
	let t = confirm(`${loc} 사과를 삭제하시겠습니까 ?`);
	if (t) {
		location.href = "AppleDeleteController?a_location=" + loc;
	}
}